#include <iostream>
#include <tyv.h>
#include <fillablenode.h>

using namespace std;
struct Node* Transverse(struct Node* root);

struct Stack{
    struct Node* data;
    struct Stack *next;
};
struct Stack* top = NULL;

void push(struct Node* val){
struct Stack* newnode=(struct Stack*)malloc(sizeof(struct Stack));
newnode->data=val;
newnode->next=top;
top=newnode;
}

struct Node* pull(){
    struct Node* val;
    if(top==NULL){
        cout<<"Stack is underflow"<<endl;
        return NULL;
    }else {

    val=top->data;
    top=top->next;
    }
return val;
}

int main()
{
    //Get Binary Data to Transverse
    fillablenode fillNodeObject;
    struct Node* voot = fillNodeObject.getBinaryTree();

    //Traverse & display the data in Screen
    Transverse(voot);
    //End of the Program
    return 0;
}

struct Node* Transverse(struct Node* root){
    struct Node* pointer;

    //Root-Left-Right

    if(root==NULL){
        cout<<"Tree is Empty !"<<endl;
    }else {
    pointer=root;
    }

    while(pointer!=NULL){
        cout<< pointer->data;
        if(pointer->right!=NULL){
            push(pointer->right);
        }

        if(pointer->left!=NULL){
           pointer=pointer->left;
        }
        else{
        pointer=pull();
        }

    }




    return root;
}

