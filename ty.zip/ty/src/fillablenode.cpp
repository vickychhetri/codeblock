#include "fillablenode.h"

fillablenode::fillablenode()
{
  this->root = new Node('A');
   this->root->left = new Node('B');
    this->root->right = new Node('C');
    /* 2 and 3 become left and right children of 1
                    A
                  /    \
                 B       C
               /  \     /  \
            NULL NULL  NULL NULL
    */

    this->root->left->left = new Node('D');
    this->root->left->right = new Node('E');
    /* 4 becomes left child of 2
               A
            /     \
           B       C
          / \     / \
         D   E   NULL NULL
        / \
     NULL NULL
    */
}

fillablenode::~fillablenode()
{
    //dtor
}
