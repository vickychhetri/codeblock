#ifndef FILLABLENODE_H
#define FILLABLENODE_H
#include <tyv.h>
class fillablenode
{
    public:
        fillablenode();
        virtual ~fillablenode();


    struct Node* getBinaryTree(){
    return this->root;
    }


    protected:

    private:
        struct Node* root;
};

#endif // FILLABLENODE_H
