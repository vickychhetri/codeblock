#ifndef TYV_H
#define TYV_H
#include <iostream>
struct Node {
    char data;
    struct Node* left;
    struct Node* right;

    // val is the key or the value that
    // has to be added to the data part
    Node(char val)
    {
        data = val;

        // Left and right child for node
        // will be initialized to null
        left = NULL;
        right = NULL;
    }
};
#endif // TYV_H
